document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("registration-form").addEventListener("submit", function (event) {
        event.preventDefault();
        if (validateForm()) {
            alert("Form submitted successfully!");
        }
    });
});

function addCourse() {
    const table = document.getElementById("course-table").getElementsByTagName("tbody")[0];
    const row = table.insertRow();
    
    row.innerHTML = `
        <td><input type="text" class="form-control" name="course" required></td>
        <td><input type="text" class="form-control" name="level" required></td>
        <td><input type="text" class="form-control" name="language" required></td>
        <td><input type="date" class="form-control" name="start-date" required></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="removeCourse(this)">Remove</button></td>
    `;
}

function removeCourse(button) {
    const row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}

function validateForm() {
    let isValid = true;
    const inputs = document.querySelectorAll("input[required]");
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add("is-invalid");
            isValid = false;
        } else {
            input.classList.remove("is-invalid");
        }
    });
    return isValid;
}